package org.example;

public enum Resultado {
    GANADOR,EMPATE,PERDEDOR;
}
